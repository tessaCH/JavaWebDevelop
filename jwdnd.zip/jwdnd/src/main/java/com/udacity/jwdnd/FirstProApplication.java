package com.udacity.jwdnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstProApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstProApplication.class, args);
	}

}
