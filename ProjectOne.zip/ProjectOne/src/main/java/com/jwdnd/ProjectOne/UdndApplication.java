package com.jwdnd.ProjectOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdndApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdndApplication.class, args);
	}

}
