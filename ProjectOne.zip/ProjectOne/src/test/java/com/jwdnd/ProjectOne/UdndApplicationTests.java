package com.jwdnd.ProjectOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdndApplicationTests {

	@Test
	void contextLoads() {
	}

}
